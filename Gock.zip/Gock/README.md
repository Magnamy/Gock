#-<Welcome>-#

    Gock {Google Hack}

# What is Gock?

Gock : It is a Google Play card guessing tool , (Free) Usable in Play Store.
Based on [Bash] , Using Openssl-tool To Generate Passwords.

# How to Use Gock?

[1] Download a VPN { ::Example 

[![NordVPN](https://play.google.com/store/apps/details?id=com.nordvpn.android)](Nord VPN , Google Play) }

[2] Run Gock.sh , Open termux , then Enter [$] bash Gock.sh `Or` [$] sh Gock.sh `if Not Work , than use` [$] ./Gock

[3] Then Take Password , For ::Example [548GH-OOOOCX-ALPH12-TR89E]

[4] Then go to > Settings > Apps > Google Play > Delete data

[5] Then Run [Nord VPN] to USA [Or] Germany

[6] Then Go and Open [Google Play] > Get the value of the code > Paste the Google Play Card Password you Generated it in Gock

[7] Go to Pubg , Clash of Clans , ...etc And Sell UC or Jewels. Enjoy !

# Copyrgiht (C) #

Author : Magnamy

Powered by MacMan CDXC

Created by Rajkumardusad

Github : [![Source](https://github.com/rajkumardusad)

**<- Warning ->**

We are not responsible for any misuse or error in downloading harmful files [Viruses].

#-<End>-#
